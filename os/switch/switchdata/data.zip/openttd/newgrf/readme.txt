
			The Temperate Set
			for TTDPatch

			by Michael Blunck
			www.patagonia.de.vu/ttd

			22.01.2003
	
			Version 4
			14.07.2003



1. Version update
============

This is a new update of the "TempSet" with some bugs removed and modified to work under the new patch.

- Bugs removed

fixed some graphical inconsistencies, mainly with the menu entries which have been sometimes too long to fit in the menues. Also, the long engines (Thalys etc) showed a somewhat inconsistent spacing of carriages when driving horizontally.

- graphics modifications

Most of the engines have been modified with regard to better shading and colouring keeping track with the improvements in vehicle developing underway for other sets. Some of the engines in player colour scheme have been improved too, e.g. the "Thalys".

Additionally, engines which are part of the DBSet have been improved by using their better fitting carriages from that set.

- general modifications

The TempSet has been modified to work under the new patch. Most notably you don�t need to keep track of your newgrf(w) file anymore.  The TempSet now is only active in the temperate climate, i.e. you can have both the TempSet and the ArcticSet in your newgrf file.
 

2. Introduction
==========

This new set of ten locomotives is intended for the temperate climate. Five of these locomotives are prepared to set up trainsets by "wagon override", i.e. when adding a passenger or mail carriage to one of these locomotives the graphics of the carriages is changed automatically to fit the train set type.

The "TempSet" allows suppressing of any of its constituents by applying a special parameter. This is a handy feature especially if you�d like to add foreign engines which would otherwise use the same vehicle-ID as one of the TempSet. (see 2. Installation)

Additionally, the TempSet comes in two versions:

- tempset.grf - this is the original TempSet. Although most engines have some decal in player-colour, they are close to original livery,

- tempsetp.grf - is a variant TempSet with more player-colour applied to the engines for those who won�t miss the old scheme.

Please note that some of the engines of the TempSet are slightly longer than the original engines in ttd. This has been done to retain the proportions of the historic originals, especially for the high speed trains. However,.depending on the scheme ttd places train vehicles in a fixed, equidistant mode, these longer engines wouldn�t keep the required distance to each other when used in multi-traction. Nevertheless, there are five engines which are safe for use in multitraction: V200, class 101, class 252, class 269 and the Re 460. The other five are "elongated" engines and should not be used in multitraction due to the resulting graphical incompatibility. However, two of them are special "head units" (for the ICE3 and TGV "Thalys" train sets) anyway and the other three engines are very powerful on their own and haven�t been used in multi-traction in reality either. So there should be no need to use them in multi-traction.

*** You�ll need TTDPatch version 2.0 (or higher) to run the TempSet. ***

The actual version of the TempSet is 2.4 (Grf-ID is 6D 62 02 04).


3. Copyright and Copying
==================

The graphics and code of the TempSet are Copyright (C) 2002-2003 by Michael Blunck.  The TempSet is distributed under the terms of the GNU general public license (GPL).  For more information please read the GNU GPL page (http://www.fsf.org/copyleft/).  A copy of the license should have come with the TempSet in the file 'COPYING', if not please read the license (http://www.fsf.org/copyleft/gpl.html).

In particular, the standard warranty disclaimer applies:

BECAUSE THE PROGRAM IS SUPPLIED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR
DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
(INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF
THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR
OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


4. Installation
=========

Unzip the TempSet zip file into the directory "newgrf" and add it to the "newgrf.cfg" file in the ttd directory by placing following line into that file:

newgrf/tempset.grf

or, if you don�t like the original liveries:

newgrf/tempsetp.grf. 

Remember that you have to start TTD in "temperate mode" to get the new engines. However, you can keep the TempSet entry in your "newgrf.cfg" file even when playing e.g. arctic climate because both sets now check for the right climate to be activated in.

Anyway, it�s still important to use exactly the same configuration when re-playing a saved game. If you change the content of the newgrf.cfg file between saves, you�ll get unpredictable results.  

To allow for more flexibility, it�s possible now to suppress any of the engines in the TempSet by simply applying a parameter to the set name in "newgrf.cfg".

E.g. the line "newgrf/tempset.grf" makes available all engines and train sets, but "newgrf/tempset.grf 608" masks the class 252 and 269 electrics and the DE-AC33C "blue tiger" diesel. The needed numbers are constructed simply by adding together these values:

1	V200
2	class 103
4	class 101
8	ICE3
16	Thalys
32	class 269	
64	class 252
128	Re 66
256	Re 460
512	DE-AC33C

Example:

32	class 269
+64	class 252
+512	DE-AC33C
-------------------------
= 608 

*** You�ll need TTDPatch version 2.0 (or higher) to run the TempSet. ***

The actual version of the TempSet is 2.4 (Grf-ID is 6D 62 02 04).

5. The new vehicles
=============

You should check the web site www.patagonia.de.vu/ttd to get detailed information about the characteristics of the models and the original locomotives.

5.1 locomotives
----------------

1. the famous german V200 diesel locomotive gives a good game start in the 1950�s

2. the even more famous class 103, one of  the first high-speed electrics built in large quantities in europe. Originally capable of a max speed of 280 km/h, it�s restricted to 200 km/h in the game. Being in the special TEE livery the set includes suitable carriages for passengers and baggage/mail. This is a "long" engine.

3. the german class 101, a very powerful modern electric engine built by Adtranz which can be used both for fast passenger service and heavy cargo trains. The model is in the "traffic-red" livery of the DB. The set includes carriages for passengers and baggage/mail.

4. the ICE-3 train set of DB, complete with coaches and a mail carriage (although there�s none in reality). Developed for 330 km/h this is the fastest train in the game so far. This is a "long" engine.

5. the TGV PBA "Thalys" of SNCF is another high-speed train set. Coaches and a mail carriage are included, too. This is a "long" engine too.

6. the class 269 of spanish Renfe, developed originally by Mitsubishi, is a very interesting and well-used engine from the 1980�s. This model is in attractive yellow-gray livery.

7. the class 252 of Renfe, a variety of the popular "eurosprinter", a modern and very powerful electric engine also in Renfe livery.

8. the swiss Re 6/6, one of  the world�s most powerful locomotives. Another "long" engine.

9. the swiss Re 460, another variant of the "Lok2000".

10. the DE-AC33C "Blue Tiger", a most modern diesel electric. A "long" engine too.


These are the vehicle IDs used for the TempSet engines.

(An entry denoted as "n/a" isn�t available in temperate climate and "-" denotes a "free slot" which could hold some more engines for the temperate climate)

veh-ID	type		launch year		

00 	n/a
01	V200		1953	
02 	BR103		1964	
03 	BR101		1996		
04 	ICE 3		1999	
05 	Thalys		1995	
06 	class 269		1980	
07 	class252		1992	

08 - 0F 	n/a

10 	Re 66		1972	
11 	Re 460		1994		
12	DE-AC33C	1997		
13 	-		
14 	-		
15 	-		
16 	n/a		
17 	n/a			
18 	n/a			
19 	n/a			
1A	n/a		


5.2. Carriages
---------------

Some of the TempSet engines are mainly used for passenger trains, usually in train sets in a unified livery for both engine and carriages. The new patch makes available a special feature to build such train sets easily, it�s called "wagon overide". Some engines of the TempSet are supporting this feature to give you suitable passenger and/or mail carriages by simply choosing the "normal" carriages in the depot menu.

These engines allow for "wagon override", both for passenger and mail carriages:

- V200
- BR103
- BR 101
- ICE 3
- Thalys


6. Acknowledgements
===============

The availability of new vehicles was only possible by the outstanding work of Josef Drexler and Marcin Grzegorczyk on the TTDPatch. In particular I�d like to express my gratitude to Josef for the fruitful collaboration during further developing the patch.  

